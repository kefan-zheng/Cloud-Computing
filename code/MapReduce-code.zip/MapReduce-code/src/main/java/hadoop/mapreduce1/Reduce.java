package hadoop.mapreduce1;
import java.io.IOException;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Reduce extends Reducer<Text, DoubleWritable, Text, DoubleWritable>{
    @Override
    public void reduce(Text key, Iterable<DoubleWritable> values, Context context)
            throws IOException, InterruptedException {

        //平均通话次数=计算一月中的总通话次数/天数
        //遍历计算次数
        double call_num = 0;
        for (DoubleWritable value : values) {
            call_num += value.get();
        }
        double average_call_num = call_num/29;
        context.write(key, new DoubleWritable(average_call_num));
    }
}
