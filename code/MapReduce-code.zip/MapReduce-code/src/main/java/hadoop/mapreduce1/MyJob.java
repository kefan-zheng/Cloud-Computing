package hadoop.mapreduce1;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.log4j.BasicConfigurator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class MyJob {

    public static void main(String[] args) throws Exception {

        final Logger logger = LoggerFactory.getLogger(MyJob.class);


        Configuration conf = new Configuration();
        Job job = new Job(conf);
        //指定运行的作业类
        job.setJarByClass(MyJob.class);
        job.setJobName("Compute Case 1");

        //指定输入数据的位置
        FileInputFormat.addInputPath(job, new Path(args[0]));
        //指定输出数据的位置
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        //指定job的map处理类和reduce处理类
        job.setMapperClass(Map.class);
        job.setReducerClass(Reduce.class);

        //指定输出的key和value
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(DoubleWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(DoubleWritable.class);

        //提交执行并计算执行时间
        logger.info("Starting computing: " + job.getJobName());
        long startTime = System.nanoTime();
        job.waitForCompletion(true);
        long endTime = System.nanoTime();
        long totalTime = (endTime-startTime)/1000000;
        logger.info("Compute Time: " + totalTime + "ms");
        logger.info("Computing finished!");

    }
}
